import { Outlet, useLocation } from 'react-router-dom'
import Sidebar from '../components/layout/Sidebar'
import FooterContact from '../components/layout/FooterContact'

function MainLayout() {
  const { pathname } = useLocation()
  const isContactPage = pathname === '/contact'

  return (
    <div className="layout">
      <Sidebar />
      <div className="layout__content">
        <Outlet />
        {!isContactPage && <FooterContact />}
      </div>
    </div>
  )
}

export default MainLayout
