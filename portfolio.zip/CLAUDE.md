# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Commands

```bash
npm run dev       # start Vite dev server with HMR
npm run build     # type-check (tsc -b) then bundle for production
npm run preview   # serve the production build locally
npm run lint      # run ESLint across all TS/TSX files
```

There is no test suite configured yet.

## Architecture

This is a **personal portfolio site** being rebuilt from vanilla JS/SCSS into **React 19 + TypeScript + Vite**.

The previous implementation (removed in the current branch) was a sci-fi/space-themed portfolio with:
- Sound effects (click, hover, typing beeps, linker sounds via Web Audio)
- Typewriter-style name/status animation
- A sci-fi "linker" animation linking two points on screen
- A profile image with loading animation
- Separate `src/modules/` (UI behaviors) and `src/utils/` (reusable primitives like `soundManager`, `typeText`, `animationSequence`)

That full feature set is the target to rebuild in React. The current `src/App.tsx` is the default Vite scaffold — the real portfolio UI has not been ported yet.

### Key conventions from the old codebase to carry forward

- **Sound** was managed centrally via a `soundManager` utility (load, play, stop) keyed by sound name.
- **Animations** were sequenced via an `animationSequence` utility that ran steps in order with delays — not ad-hoc `setTimeout` chains.
- **Typing effect** was a `typeText(element, text, speed)` utility, not inline component logic.

### TypeScript config notes

`tsconfig.app.json` enforces `noUnusedLocals`, `noUnusedParameters`, and `erasableSyntaxOnly`. Keep imports and parameters clean — the build will fail otherwise.

### Asset locations

- Static assets served at `/` root: `public/favicon.svg`, `public/icons.svg`
- Imported assets (bundled): `src/assets/` (hero image, logos)
- SVG icons are sprite-based: a single `public/icons.svg` file with `<symbol>` elements, referenced via `<use href="/icons.svg#icon-id">` in JSX.
